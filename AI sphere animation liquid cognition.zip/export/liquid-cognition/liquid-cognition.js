/* Liquid Cognition — ambient animation for one transparent PNG.
   Libraries: three.js r136
   Usage:  SphereFX.ready().then(() => SphereFX.loadImage('sphere.png'))
             .then(img => SphereFX.liquidCognition(canvas, img, { speed: 1, intensity: 1, pointerFollow: true }));
   Returns { destroy() }. The loop pauses itself when the canvas scrolls out of view. */
(function () {
  var INK = [32, 30, 29], ACCENT = [236, 48, 19];

  function dpr() { return Math.min(window.devicePixelRatio || 1, 2); }

  function sizer(canvas, onResize) {
    var last = '';
    function measure() {
      var r = canvas.getBoundingClientRect();
      var w = Math.max(1, Math.round(r.width)), h = Math.max(1, Math.round(r.height));
      var key = w + 'x' + h + 'x' + dpr();
      if (key === last) return null;
      last = key;
      return { w: w, h: h, d: dpr() };
    }
    var ro = new ResizeObserver(function () { var m = measure(); if (m) onResize(m); });
    ro.observe(canvas);
    var first = measure();
    if (first) onResize(first);
    return { destroy: function () { ro.disconnect(); }, measure: measure };
  }

  function ticker(canvas, fn) {
    var raf = 0, alive = true, visible = true, last = performance.now(), clock = 0;
    var io = new IntersectionObserver(function (e) { visible = e[0].isIntersecting; }, { threshold: 0.02 });
    io.observe(canvas);
    function step(now) {
      if (!alive) return;
      var dt = Math.min(0.05, (now - last) / 1000); last = now;
      if (visible && !document.hidden) { clock += dt; fn(dt, clock); }
      raf = requestAnimationFrame(step);
    }
    raf = requestAnimationFrame(step);
    return function () { alive = false; cancelAnimationFrame(raf); io.disconnect(); };
  }

  function pointer(canvas, opts) {
    var s = { tx: 0, ty: 0, x: 0, y: 0, over: 0, tOver: 0 };
    function move(e) {
      var r = canvas.getBoundingClientRect();
      s.tx = ((e.clientX - r.left) / r.width - 0.5) * 2;
      s.ty = ((e.clientY - r.top) / r.height - 0.5) * 2;
      s.tOver = 1;
    }
    function out() { s.tx = 0; s.ty = 0; s.tOver = 0; }
    canvas.addEventListener('pointermove', move);
    canvas.addEventListener('pointerleave', out);
    s.update = function (k) {
      var f = opts.pointerFollow === false ? 0 : 1;
      s.x += (s.tx * f - s.x) * k;
      s.y += (s.ty * f - s.y) * k;
      s.over += (s.tOver * f - s.over) * k;
    };
    s.destroy = function () {
      canvas.removeEventListener('pointermove', move);
      canvas.removeEventListener('pointerleave', out);
    };
    return s;
  }

  function rgba(c, a) { return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a.toFixed(3) + ')'; }
  function num(v, d) { return typeof v === 'number' && isFinite(v) ? v : d; }

  /* ──────────────────────── 1b — Liquid Cognition (WebGL) ─────────────────── */
  var LIQUID_FRAG = [
    'precision highp float;',
    'uniform sampler2D map; uniform float uTime, uAmp, uOver;',
    'varying vec2 vUv;',
    'float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }',
    'float noise(vec2 p){',
    '  vec2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f);',
    '  return mix(mix(hash(i),hash(i+vec2(1.,0.)),f.x), mix(hash(i+vec2(0.,1.)),hash(i+vec2(1.,1.)),f.x), f.y);',
    '}',
    'void main(){',
    '  vec2 uv=vUv; vec2 c=uv-0.5; float r=length(c); vec2 dir=c/max(r,1e-4);',
    '  float t=uTime;',
    '  float n1=noise(uv*3.2+vec2(t*0.11,-t*0.08));',
    '  float n2=noise(uv*6.5-vec2(t*0.14,t*0.10));',
    '  float n3=noise(uv*11.0+vec2(t*0.07,t*0.16));',
    '  vec2 flow=vec2(n1-0.5,n2-0.5);',
    '  float breath=0.55+0.45*sin(t*0.7);',
    '  float wavePhase=fract(t*0.19);',
    '  float ring=exp(-pow((r-wavePhase*0.78)/0.05,2.0))*smoothstep(0.02,0.12,wavePhase)*(1.0-wavePhase*0.55);',
    '  float ring2=exp(-pow((r-fract(t*0.19+0.5)*0.78)/0.07,2.0))*0.5;',
    '  float amp=uAmp*(0.0072+0.0042*breath);',
    '  vec2 disp=flow*amp + dir*(ring+ring2*0.6)*0.016*uAmp;',
    '  float k=(0.0014+0.0032*(ring+ring2*0.5))*uAmp*(1.0+uOver*0.5);',
    '  vec4 cr=texture2D(map, uv+disp+dir*k);',
    '  vec4 cg=texture2D(map, uv+disp);',
    '  vec4 cb=texture2D(map, uv+disp-dir*k);',
    '  float a=max(max(cr.a,cg.a),cb.a);',
    '  vec3 col=vec3(cr.r,cg.g,cb.b);',
    '  col += a*(ring*0.20+ring2*0.06);',
    '  col += a*(n3-0.5)*0.07*(0.6+0.4*breath);',
    '  col -= a*vec3(0.02,0.012,0.0)*uOver;',
    '  gl_FragColor=vec4(col, a*smoothstep(0.0,0.06,a));',
    '}'
  ].join('\n');

  var PASS_VERT = [
    'varying vec2 vUv;',
    'void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }'
  ].join('\n');

  function glStage(canvas) {
    var T = window.THREE;
    var renderer = new T.WebGLRenderer({
      canvas: canvas, alpha: true, antialias: true,
      premultipliedAlpha: false, preserveDrawingBuffer: true /* keeps the canvas readable for screenshots */
    });
    renderer.setClearColor(0x000000, 0);
    var scene = new T.Scene();
    var cam = new T.OrthographicCamera(-1, 1, 1, -1, 0.01, 10);
    cam.position.z = 2;
    function resize(m) {
      renderer.setPixelRatio(m.d);
      renderer.setSize(m.w, m.h, false);
      var asp = m.w / m.h;
      cam.left = -asp; cam.right = asp; cam.top = 1; cam.bottom = -1; cam.updateProjectionMatrix();
    }
    return { T: T, renderer: renderer, scene: scene, cam: cam, resize: resize };
  }

  function liquidCognition(canvas, img, opts) {
    opts = opts || {};
    var s = glStage(canvas), T = s.T;
    var tex = new T.Texture(img);
    tex.minFilter = T.LinearFilter; tex.magFilter = T.LinearFilter;
    tex.generateMipmaps = false; tex.needsUpdate = true;
    var mat = new T.ShaderMaterial({
      uniforms: { map: { value: tex }, uTime: { value: 0 }, uAmp: { value: 1 }, uOver: { value: 0 } },
      vertexShader: PASS_VERT, fragmentShader: LIQUID_FRAG,
      transparent: true, depthTest: false, depthWrite: false
    });
    var mesh = new T.Mesh(new T.PlaneGeometry(2, 2), mat);
    mesh.scale.set(0.88, 0.88, 1);
    s.scene.add(mesh);

    var pt = pointer(canvas, opts);
    var size = sizer(canvas, s.resize);
    var clock = 0;
    var stop = ticker(canvas, function (dt) {
      var sp = num(opts.speed, 1), iv = num(opts.intensity, 1);
      pt.update(0.05);
      clock += dt * sp;
      mat.uniforms.uTime.value = clock;
      mat.uniforms.uAmp.value = iv;
      mat.uniforms.uOver.value = pt.over;
      mesh.position.x = pt.x * 0.05;
      mesh.position.y = -pt.y * 0.05;
      mesh.rotation.z = pt.x * 0.03;
      var b = 1 + 0.012 * Math.sin(clock * 0.7);
      mesh.scale.set(0.88 * b, 0.88 * b, 1);
      s.renderer.render(s.scene, s.cam);
    });

    return {
      destroy: function () {
        stop(); size.destroy(); pt.destroy();
        mesh.geometry.dispose(); mat.dispose(); tex.dispose();
        s.renderer.dispose();
      }
    };
  }

    window.SphereFX = {
    liquidCognition: liquidCognition,
    loadImage: function (src) {
      return new Promise(function (res, rej) {
        var im = new Image();
        im.crossOrigin = 'anonymous';
        im.onload = function () { res(im); };
        im.onerror = rej;
        im.src = src;
      });
    },
    ready: function () {
      return new Promise(function (res) {
        (function poll() {
          if (window.THREE && window.gsap) return res();
          setTimeout(poll, 40);
        })();
      });
    }
  };
})();
