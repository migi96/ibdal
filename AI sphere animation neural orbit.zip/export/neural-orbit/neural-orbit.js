/* Neural Orbit — ambient animation for one transparent PNG.
   Libraries: GSAP 3
   Usage:  SphereFX.ready().then(() => SphereFX.loadImage('sphere.png'))
             .then(img => SphereFX.neuralOrbit(canvas, img, { speed: 1, intensity: 1, pointerFollow: true }));
   Returns { destroy() }. The loop pauses itself when the canvas scrolls out of view. */
(function () {
  var INK = [32, 30, 29], ACCENT = [236, 48, 19];

  function dpr() { return Math.min(window.devicePixelRatio || 1, 2); }

  function sizer(canvas, onResize) {
    var last = '';
    function measure() {
      var r = canvas.getBoundingClientRect();
      var w = Math.max(1, Math.round(r.width)), h = Math.max(1, Math.round(r.height));
      var key = w + 'x' + h + 'x' + dpr();
      if (key === last) return null;
      last = key;
      return { w: w, h: h, d: dpr() };
    }
    var ro = new ResizeObserver(function () { var m = measure(); if (m) onResize(m); });
    ro.observe(canvas);
    var first = measure();
    if (first) onResize(first);
    return { destroy: function () { ro.disconnect(); }, measure: measure };
  }

  function ticker(canvas, fn) {
    var raf = 0, alive = true, visible = true, last = performance.now(), clock = 0;
    var io = new IntersectionObserver(function (e) { visible = e[0].isIntersecting; }, { threshold: 0.02 });
    io.observe(canvas);
    function step(now) {
      if (!alive) return;
      var dt = Math.min(0.05, (now - last) / 1000); last = now;
      if (visible && !document.hidden) { clock += dt; fn(dt, clock); }
      raf = requestAnimationFrame(step);
    }
    raf = requestAnimationFrame(step);
    return function () { alive = false; cancelAnimationFrame(raf); io.disconnect(); };
  }

  function pointer(canvas, opts) {
    var s = { tx: 0, ty: 0, x: 0, y: 0, over: 0, tOver: 0 };
    function move(e) {
      var r = canvas.getBoundingClientRect();
      s.tx = ((e.clientX - r.left) / r.width - 0.5) * 2;
      s.ty = ((e.clientY - r.top) / r.height - 0.5) * 2;
      s.tOver = 1;
    }
    function out() { s.tx = 0; s.ty = 0; s.tOver = 0; }
    canvas.addEventListener('pointermove', move);
    canvas.addEventListener('pointerleave', out);
    s.update = function (k) {
      var f = opts.pointerFollow === false ? 0 : 1;
      s.x += (s.tx * f - s.x) * k;
      s.y += (s.ty * f - s.y) * k;
      s.over += (s.tOver * f - s.over) * k;
    };
    s.destroy = function () {
      canvas.removeEventListener('pointermove', move);
      canvas.removeEventListener('pointerleave', out);
    };
    return s;
  }

  function rgba(c, a) { return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a.toFixed(3) + ')'; }
  function num(v, d) { return typeof v === 'number' && isFinite(v) ? v : d; }

  /* ─────────────────────────── 1a — Neural Orbit ─────────────────────────── */
  function neuralOrbit(canvas, img, opts) {
    opts = opts || {};
    var ctx = canvas.getContext('2d');
    var W = 1, H = 1, D = 1;
    var size = sizer(canvas, function (m) {
      W = m.w; H = m.h; D = m.d;
      canvas.width = Math.round(W * D); canvas.height = Math.round(H * D);
    });
    var pt = pointer(canvas, opts);

    // node shell
    var N = 34, nodes = [], ga = Math.PI * (3 - Math.sqrt(5));
    for (var i = 0; i < N; i++) {
      var y = 1 - (i / (N - 1)) * 2, rr = Math.sqrt(Math.max(0, 1 - y * y)), th = ga * i;
      nodes.push([Math.cos(th) * rr, y, Math.sin(th) * rr]);
    }
    var edges = [];
    for (var a = 0; a < N; a++) for (var b = a + 1; b < N; b++) {
      var dx = nodes[a][0] - nodes[b][0], dy = nodes[a][1] - nodes[b][1], dz = nodes[a][2] - nodes[b][2];
      var d3 = Math.sqrt(dx * dx + dy * dy + dz * dz);
      if (d3 < 0.62) edges.push([a, b]);
    }
    // three great-circle rings, tilted like the ribbons in the render
    function basis(ax, ay, az) {
      var n = [ax, ay, az], l = Math.hypot(ax, ay, az); n = [ax / l, ay / l, az / l];
      var t = Math.abs(n[1]) > 0.9 ? [1, 0, 0] : [0, 1, 0];
      var u = [n[1] * t[2] - n[2] * t[1], n[2] * t[0] - n[0] * t[2], n[0] * t[1] - n[1] * t[0]];
      var lu = Math.hypot(u[0], u[1], u[2]); u = [u[0] / lu, u[1] / lu, u[2] / lu];
      var v = [n[1] * u[2] - n[2] * u[1], n[2] * u[0] - n[0] * u[2], n[0] * u[1] - n[1] * u[0]];
      return [u, v];
    }
    var rings = [basis(0.2, 1, 0.15), basis(1, 0.25, -0.3), basis(-0.35, 0.4, 1)];

    var yaw = 0.3, pitch = -0.12;
    function rot(p, yw, pc) {
      var cy = Math.cos(yw), sy = Math.sin(yw);
      var x = p[0] * cy + p[2] * sy, z = -p[0] * sy + p[2] * cy, y = p[1];
      var cp = Math.cos(pc), sp = Math.sin(pc);
      return [x, y * cp - z * sp, y * sp + z * cp];
    }

    // GSAP choreography: travelling signals + periodic inference burst
    var g = window.gsap, tweens = [], pulses = [], burst = { r: 0, a: 0 };
    function schedule() {
      if (!g) return;
      var e = edges[(Math.random() * edges.length) | 0];
      var o = { p: 0, a: 1, e: e };
      pulses.push(o);
      tweens.push(g.to(o, {
        p: 1, duration: 0.9 + Math.random() * 0.7, ease: 'power2.inOut',
        onComplete: function () { var k = pulses.indexOf(o); if (k > -1) pulses.splice(k, 1); }
      }));
      tweens.push(g.delayedCall(0.28 + Math.random() * 0.5, schedule));
    }
    function bursts() {
      if (!g) return;
      var tl = g.timeline({ onComplete: function () { tweens.push(g.delayedCall(3.4, bursts)); } });
      tl.set(burst, { r: 0, a: 0.9 })
        .to(burst, { r: 1, duration: 2.6, ease: 'power2.out' }, 0)
        .to(burst, { a: 0, duration: 2.6, ease: 'power1.in' }, 0);
      tweens.push(tl);
    }
    if (g) { schedule(); tweens.push(g.delayedCall(1.6, bursts)); }

    var stop = ticker(canvas, function (dt, t) {
      var sp = num(opts.speed, 1), iv = num(opts.intensity, 1);
      pt.update(0.055);
      yaw += dt * 0.17 * sp * (1 + pt.x * 0.9);
      pitch += ((-0.12 + pt.y * 0.42) - pitch) * 0.05;

      ctx.setTransform(D, 0, 0, D, 0, 0);
      ctx.clearRect(0, 0, W, H);
      var cx = W / 2, cy = H / 2;
      var base = Math.min(W, H) * 0.325;                    // sphere radius on screen
      var breath = 1 + 0.017 * Math.sin(t * 0.85 * sp) * iv;
      var shell = base * (1.235 + 0.02 * Math.sin(t * 0.6 * sp));
      var floatY = Math.sin(t * 0.55 * sp) * 4 * iv;

      var proj = nodes.map(function (p) {
        var r = rot(p, yaw, pitch);
        return { x: cx + r[0] * shell + pt.x * 6, y: cy - r[1] * shell + floatY + pt.y * 6, z: r[2] };
      });

      function ringPath(ring, front) {
        ctx.lineWidth = 1.25;
        var steps = 80, prev = null;
        for (var s = 0; s <= steps; s++) {
          var ang = (s / steps) * Math.PI * 2 + t * 0.11 * sp;
          var p = [
            ring[0][0] * Math.cos(ang) + ring[1][0] * Math.sin(ang),
            ring[0][1] * Math.cos(ang) + ring[1][1] * Math.sin(ang),
            ring[0][2] * Math.cos(ang) + ring[1][2] * Math.sin(ang)
          ];
          var r = rot(p, yaw, pitch);
          var cur = { x: cx + r[0] * shell * 1.1 + pt.x * 6, y: cy - r[1] * shell * 1.1 + floatY + pt.y * 6, z: r[2] };
          if (prev) {
            var mz = (prev.z + cur.z) / 2;
            if ((front && mz >= 0) || (!front && mz < 0)) {
              ctx.strokeStyle = rgba(INK, (front ? 0.16 : 0.07) * (0.45 + 0.55 * Math.abs(mz)));
              ctx.beginPath(); ctx.moveTo(prev.x, prev.y); ctx.lineTo(cur.x, cur.y); ctx.stroke();
            }
          }
          prev = cur;
        }
      }
      function mesh(front) {
        for (var e = 0; e < edges.length; e++) {
          var A = proj[edges[e][0]], B = proj[edges[e][1]], mz = (A.z + B.z) / 2;
          if (front ? mz < 0 : mz >= 0) continue;
          ctx.strokeStyle = rgba(INK, (front ? 0.2 : 0.075) * (0.35 + 0.65 * (mz + 1) / 2));
          ctx.lineWidth = front ? 1 : 0.8;
          ctx.beginPath(); ctx.moveTo(A.x, A.y); ctx.lineTo(B.x, B.y); ctx.stroke();
        }
        for (var n = 0; n < proj.length; n++) {
          var P = proj[n];
          if (front ? P.z < 0 : P.z >= 0) continue;
          var dep = (P.z + 1) / 2;
          var flick = 0.55 + 0.45 * Math.sin(t * 1.7 * sp + n * 1.3);
          ctx.fillStyle = rgba(INK, (front ? 0.5 : 0.14) * (0.3 + 0.7 * dep) * flick);
          ctx.beginPath(); ctx.arc(P.x, P.y, (front ? 2.1 : 1.5) * (0.6 + 0.4 * dep), 0, 6.2832); ctx.fill();
        }
      }

      rings.forEach(function (r) { ringPath(r, false); });
      mesh(false);

      // the object itself — breathing, drifting, never fully still
      var ds = base * 2 * breath;
      ctx.save();
      ctx.translate(cx + pt.x * 10, cy + floatY + pt.y * 10);
      ctx.rotate(Math.sin(t * 0.23 * sp) * 0.035);
      ctx.globalAlpha = 1;
      ctx.drawImage(img, -ds / 2, -ds / 2, ds, ds);
      ctx.restore();

      rings.forEach(function (r) { ringPath(r, true); });
      mesh(true);

      // inference burst — concentric rules pushing outward
      if (burst.a > 0.001) {
        for (var k = 0; k < 2; k++) {
          var rr = base * (1.05 + burst.r * (0.95 + k * 0.22));
          ctx.strokeStyle = rgba(INK, burst.a * (0.16 - k * 0.06) * iv);
          ctx.lineWidth = 2 - k * 0.8;
          ctx.beginPath(); ctx.arc(cx + pt.x * 10, cy + floatY + pt.y * 10, rr, 0, 6.2832); ctx.stroke();
        }
      }

      // signals riding the mesh
      for (var q = 0; q < pulses.length; q++) {
        var o = pulses[q], A2 = proj[o.e[0]], B2 = proj[o.e[1]];
        var ease = o.p, x = A2.x + (B2.x - A2.x) * ease, y = A2.y + (B2.y - A2.y) * ease;
        var vis = 0.35 + 0.65 * ((A2.z + B2.z) / 2 + 1) / 2;
        ctx.strokeStyle = rgba(ACCENT, 0.5 * vis);
        ctx.lineWidth = 1.6;
        ctx.beginPath();
        ctx.moveTo(A2.x + (B2.x - A2.x) * Math.max(0, ease - 0.22), A2.y + (B2.y - A2.y) * Math.max(0, ease - 0.22));
        ctx.lineTo(x, y); ctx.stroke();
        ctx.fillStyle = rgba(ACCENT, 0.9 * vis);
        ctx.beginPath(); ctx.arc(x, y, 2.4, 0, 6.2832); ctx.fill();
      }
    });

    return {
      destroy: function () {
        stop(); size.destroy(); pt.destroy();
        tweens.forEach(function (t) { t && t.kill && t.kill(); });
      }
    };
  }

    window.SphereFX = {
    neuralOrbit: neuralOrbit,
    loadImage: function (src) {
      return new Promise(function (res, rej) {
        var im = new Image();
        im.crossOrigin = 'anonymous';
        im.onload = function () { res(im); };
        im.onerror = rej;
        im.src = src;
      });
    },
    ready: function () {
      return new Promise(function (res) {
        (function poll() {
          if (window.gsap) return res();
          setTimeout(poll, 40);
        })();
      });
    }
  };
})();
