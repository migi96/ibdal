/* Grid Ingest — ambient animation for one transparent PNG.
   Libraries: GSAP · Canvas 2D
   Usage:  TilesFX.ready().then(() => TilesFX.loadImage('tiles.png'))
             .then(img => TilesFX.gridIngest(canvas, img, { speed: 1, intensity: 1, pointerFollow: true }));
   Returns { destroy() }. The loop pauses itself when the canvas scrolls out of view. */
(function () {
  var INK = [32, 30, 29], ACCENT = [236, 48, 19];
  var PALETTE = [
    [35, 52, 198], [74, 92, 216], [110, 124, 228],
    [154, 166, 238], [223, 227, 238], [242, 244, 249]
  ];

  function dpr() { return Math.min(window.devicePixelRatio || 1, 2); }
  function num(v, d) { return typeof v === 'number' && isFinite(v) ? v : d; }
  function rgba(c, a) { return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a.toFixed(3) + ')'; }

  function sizer(canvas, onResize) {
    var last = '';
    function measure() {
      var r = canvas.getBoundingClientRect();
      var w = Math.max(1, Math.round(r.width)), h = Math.max(1, Math.round(r.height));
      var key = w + 'x' + h + 'x' + dpr();
      if (key === last) return null;
      last = key;
      return { w: w, h: h, d: dpr() };
    }
    var ro = new ResizeObserver(function () { var m = measure(); if (m) onResize(m); });
    ro.observe(canvas);
    var first = measure();
    if (first) onResize(first);
    return { destroy: function () { ro.disconnect(); } };
  }

  function ticker(canvas, fn) {
    var raf = 0, alive = true, visible = true, last = performance.now(), clock = 0;
    var io = new IntersectionObserver(function (e) { visible = e[0].isIntersecting; }, { threshold: 0.02 });
    io.observe(canvas);
    function step(now) {
      if (!alive) return;
      var dt = Math.min(0.05, (now - last) / 1000); last = now;
      if (visible && !document.hidden) { clock += dt; fn(dt, clock); }
      raf = requestAnimationFrame(step);
    }
    raf = requestAnimationFrame(step);
    return function () { alive = false; cancelAnimationFrame(raf); io.disconnect(); };
  }

  function pointer(canvas, opts) {
    var s = { tx: 0, ty: 0, x: 0, y: 0, over: 0, tOver: 0 };
    function move(e) {
      var r = canvas.getBoundingClientRect();
      s.tx = ((e.clientX - r.left) / r.width - 0.5) * 2;
      s.ty = ((e.clientY - r.top) / r.height - 0.5) * 2;
      s.tOver = 1;
    }
    function out() { s.tx = 0; s.ty = 0; s.tOver = 0; }
    canvas.addEventListener('pointermove', move);
    canvas.addEventListener('pointerleave', out);
    s.update = function (k) {
      var f = opts.pointerFollow === false ? 0 : 1;
      s.x += (s.tx * f - s.x) * k;
      s.y += (s.ty * f - s.y) * k;
      s.over += (s.tOver * f - s.over) * k;
    };
    s.destroy = function () {
      canvas.removeEventListener('pointermove', move);
      canvas.removeEventListener('pointerleave', out);
    };
    return s;
  }

/* ──────────────────────────── 2b — Grid Ingest ───────────────────────────── */
  function gridIngest(canvas, img, opts) {
    opts = opts || {};
    var ctx = canvas.getContext('2d');
    var W = 1, H = 1, D = 1, art = null, cells = [], side = 0, GX = 15;
    var pt = pointer(canvas, opts);

    function build() {
      side = Math.round(Math.min(W, H) * 0.66);
      art = document.createElement('canvas');
      art.width = art.height = Math.round(side * D);
      var actx = art.getContext('2d');
      actx.drawImage(img, 0, 0, art.width, art.height);
      var data = actx.getImageData(0, 0, art.width, art.height).data;
      var step = art.width / GX;
      cells = [];
      for (var gy = 0; gy < GX; gy++) for (var gx = 0; gx < GX; gx++) {
        var sx = Math.floor(gx * step), sy = Math.floor(gy * step);
        var sw = Math.ceil(step), sh = Math.ceil(step);
        var solid = 0;
        for (var y = sy; y < Math.min(sy + sh, art.height); y += 3)
          for (var x = sx; x < Math.min(sx + sw, art.width); x += 3)
            if (data[(y * art.width + x) * 4 + 3] > 40) solid++;
        if (!solid) continue;
        cells.push({ sx: sx, sy: sy, sw: sw, sh: sh, ux: (gx + 0.5) / GX - 0.5, uy: (gy + 0.5) / GX - 0.5 });
      }
    }
    var size = sizer(canvas, function (m) {
      W = m.w; H = m.h; D = m.d;
      canvas.width = Math.round(W * D); canvas.height = Math.round(H * D);
      build();
    });

    // scan band travels along the artwork's isometric axis, pausing between passes
    var g = window.gsap, band = { p: -0.86 }, tl = null;
    if (g) {
      tl = g.timeline({ repeat: -1 })
        .to(band, { p: 0.86, duration: 4.4, ease: 'none' })
        .to(band, { p: 0.86, duration: 1.0 })
        .set(band, { p: -0.86 });
    }
    var UX = 0.866, UY = 0.5;   // band normal, matching the tile grid

    var stop = ticker(canvas, function (dt, t) {
      var sp = num(opts.speed, 1), iv = num(opts.intensity, 1);
      if (tl) tl.timeScale(sp);
      pt.update(0.055);
      ctx.setTransform(D, 0, 0, D, 0, 0);
      ctx.clearRect(0, 0, W, H);
      if (!art) return;
      var cx = W / 2 + pt.x * 10, cy = H / 2 + pt.y * 8;
      var floatY = Math.sin(t * 0.5 * sp) * 4 * iv;
      var b = band.p, lift = side * 0.05 * iv;
      var ox = cx - side / 2, oy = cy - side / 2 + floatY;
      ctx.drawImage(art, ox, oy, side, side);          // intact base — lifted cells ride on top
      var hot = [];

      for (var i = 0; i < cells.length; i++) {
        var c = cells[i];
        var proj = c.ux * UX + c.uy * UY;
        var gate = Math.exp(-Math.pow((proj - b) / 0.058, 2));
        if (gate < 0.04) continue;
        var dx = ox + c.sx / D, dy = oy + c.sy / D;
        var cw = c.sw / D + 0.5, ch = c.sh / D + 0.5;
        ctx.save();
        ctx.globalAlpha = 0.10 * gate;
        ctx.drawImage(art, c.sx, c.sy, c.sw, c.sh, dx + 1.5, dy + 2.5, cw, ch);   // cast
        ctx.restore();
        ctx.drawImage(art, c.sx, c.sy, c.sw, c.sh, dx, dy - gate * lift, cw, ch);
        if (gate > 0.6) hot.push([dx, dy - gate * lift, cw, ch, gate]);
      }

      // the read head: a rule across the artwork plus outlines on the cells under it
      for (var k = 0; k < hot.length; k++) {
        var hc = hot[k];
        ctx.strokeStyle = rgba(INK, 0.09 * hc[4]);
        ctx.lineWidth = 1;
        ctx.strokeRect(hc[0] + 0.5, hc[1] + 0.5, hc[2], hc[3]);
      }
      if (b > -0.7 && b < 0.7) {
        var mx = cx + UX * b * side, my = cy + UY * b * side + floatY;
        var px = -UY, py = UX, len = side * 0.30;
        var fade = Math.max(0, 1 - Math.pow(Math.abs(b) / 0.62, 2));
        ctx.strokeStyle = rgba(ACCENT, 0.42 * fade);
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(mx - px * len, my - py * len);
        ctx.lineTo(mx + px * len, my + py * len);
        ctx.stroke();
        ctx.fillStyle = rgba(ACCENT, 0.8 * fade);
        ctx.beginPath(); ctx.arc(mx - px * len, my - py * len, 2.4, 0, 6.2832); ctx.fill();
        ctx.beginPath(); ctx.arc(mx + px * len, my + py * len, 2.4, 0, 6.2832); ctx.fill();
      }
    });

    return {
      destroy: function () {
        stop(); size.destroy(); pt.destroy();
        if (tl) tl.kill();
      }
    };
  }

    window.TilesFX = {
    gridIngest: gridIngest,
    loadImage: function (src) {
      return new Promise(function (res, rej) {
        var im = new Image();
        im.crossOrigin = 'anonymous';
        im.onload = function () { res(im); };
        im.onerror = rej;
        im.src = src;
      });
    },
    ready: function () {
      return new Promise(function (res) {
        (function poll() {
          if (window.gsap) return res();
          setTimeout(poll, 40);
        })();
      });
    }
  };
})();
